"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var Booklistservice_1 = require("./Booklistservice");
var BookComponent = (function () {
    function BookComponent(booklistservice) {
        this.booklistservice = booklistservice;
    }
    BookComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.booklistservice.getJSON().subscribe((function (booksData) { return _this.books = booksData; }));
    };
    BookComponent.prototype.delete = function (obj) {
        var index = this.books.indexOf(obj);
        this.books.splice(index, 1);
    };
    BookComponent.prototype.addData = function () {
        if (this.id != null && this.title != null && this.year != null && this.author != null) {
            var b = { id: this.id, title: this.title, year: this.year, author: this.author };
            this.books.push(b);
        }
        else {
            alert("insert data");
        }
    };
    BookComponent.prototype.sortById = function () {
        this.books.sort(function (a, b) { return a.id < b.id ? -1 : a.id > b.id ? 1 : 0; });
    };
    BookComponent.prototype.sortByTitle = function () {
        this.books.sort(function (a, b) { return a.title < b.title ? -1 : a.title > b.title ? 1 : 0; });
    };
    BookComponent.prototype.sortByYear = function () {
        this.books.sort(function (a, b) { return a.year < b.year ? -1 : a.year > b.year ? 1 : 0; });
    };
    BookComponent.prototype.sortByAuthor = function () {
        this.books.sort(function (a, b) { return a.author < b.author ? -1 : a.author > b.author ? 1 : 0; });
    };
    return BookComponent;
}());
BookComponent = __decorate([
    core_1.Component({
        selector: 'app-BookComponent',
        templateUrl: './BookComponent.html',
        providers: [Booklistservice_1.BookListService]
    }),
    __metadata("design:paramtypes", [Booklistservice_1.BookListService])
], BookComponent);
exports.BookComponent = BookComponent;
//# sourceMappingURL=BookComponent.js.map