import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<app-BookComponent></app-BookComponent>`,
})
export class AppComponent  { name = 'Angular'; }
