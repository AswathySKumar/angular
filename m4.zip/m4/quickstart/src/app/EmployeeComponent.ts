import {Component,OnInit} from '@angular/core';
import {Employee} from './Employee';
import {EmployeeListService} from './EmployeeListService';
import {Http} from '@angular/http';
@Component({
selector:'app-EmployeeComponent',
templateUrl:'./EmployeeComponent.html',
  providers:[EmployeeListService]
})
export class EmployeeComponent implements OnInit{
ID:number;
NAME:string;
SALARY:number;
DEPARTMENT:string;
DOJ:string;
employee:Employee[];
constructor(private employeelistservice:EmployeeListService){}
ngOnInit(){
this.employeelistservice.getJSON().subscribe((employeeData=>this.employee=employeeData));
}

delete(obj:Employee)
{
var index=this.employee.indexOf(obj);
this.employee.splice(index,1);
}
addData():void
{
if(this.ID!=null&&this.NAME!=null&&this.SALARY!=null&&this.DEPARTMENT!=null&&this.DOJ!=null)
{
let e:Employee={ID:this.ID,NAME:this.NAME,SALARY:this.SALARY,DEPARTMENT:this.DEPARTMENT,DOJ:this.DOJ};
this.employee.push(e);

}
else{
alert("insert data")
}
}
	/*sortById(): void 
  {
    this. books.sort((a,b)=>a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  }
  
  sortByTitle(): void 
  {
    this. books.sort((a,b)=>a.title < b.title ? -1 : a.title > b.title ? 1 : 0);
  }
  
   sortByYear(): void 
  {
    this. books.sort((a,b)=>a.year < b.year ? -1 : a.year > b.year ? 1 : 0);
  }
  
   sortByAuthor(): void 
  {
    this. books.sort((a,b)=>a.author < b.author ? -1 : a.author > b.author ? 1 : 0);
  }
*/
  
}