import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpModule} from '@angular/http';
import {EmployeeComponent} from './EmployeeComponent';
import {EmployeeListService} from './EmployeeListService';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';
import { EmployeeSearchComponent }  from './app.employeesearchcomponent';
const appRoutes: Routes=[
                     { path: '',  redirectTo:'/getdata',pathMatch: 'full'},
                     { path: 'getdata',  component: EmployeeComponent},
                     {path:'search/:id',component:EmployeeSearchComponent}
                    
                      ];

@NgModule({
  imports:      [ BrowserModule,HttpModule,FormsModule,RouterModule.forRoot(appRoutes)],
  declarations: [ AppComponent,EmployeeComponent,EmployeeSearchComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
